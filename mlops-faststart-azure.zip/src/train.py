from __future__ import annotations

import os
from pathlib import Path
import json
import pandas as pd
import mlflow
import mlflow.sklearn
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.model_selection import train_test_split
import joblib

from .data import generate_synthetic_churn, save_csv

MLFLOW_URI = os.getenv("MLFLOW_TRACKING_URI", "file:./mlruns")
ARTIFACT_DIR = Path("artifacts")
DATA_RAW = Path("data/raw/synthetic_churn.csv")
LOCAL_MODEL_PATH = ARTIFACT_DIR / "model.joblib"

NUMERIC = ["age", "tenure_months", "monthly_charges"]
CATEG = ["contract_type", "is_senior", "has_support"]

def build_pipeline() -> Pipeline:
    numeric = Pipeline(steps=[("scaler", StandardScaler())])
    categ = Pipeline(steps=[("ohe", OneHotEncoder(handle_unknown="ignore"))])
    pre = ColumnTransformer(
        transformers=[
            ("num", numeric, NUMERIC),
            ("cat", categ, CATEG),
        ]
    )
    clf = LogisticRegression(max_iter=1000)
    pipe = Pipeline(steps=[("pre", pre), ("clf", clf)])
    return pipe

def main() -> dict:
    # Prepare data (generate if not present)
    if not DATA_RAW.exists():
        df = generate_synthetic_churn(n=6000)
        save_csv(df, DATA_RAW)
    else:
        df = pd.read_csv(DATA_RAW)

    X = df[NUMERIC + CATEG]
    y = df["churn"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    pipe = build_pipeline()

    mlflow.set_tracking_uri(MLFLOW_URI)
    mlflow.set_experiment("mlops-faststart")

    with mlflow.start_run() as run:
        pipe.fit(X_train, y_train)
        y_prob = pipe.predict_proba(X_test)[:, 1]
        y_pred = (y_prob >= 0.5).astype(int)
        auc = roc_auc_score(y_test, y_prob)
        acc = accuracy_score(y_test, y_pred)

        mlflow.log_param("model", "LogisticRegression")
        mlflow.log_metric("auc", float(auc))
        mlflow.log_metric("accuracy", float(acc))

        # log model to MLflow
        mlflow.sklearn.log_model(pipe, artifact_path="model", registered_model_name=None)

        # also save local artifact for FastAPI fallback
        ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
        joblib.dump(pipe, LOCAL_MODEL_PATH)

        info = {
            "run_id": run.info.run_id,
            "auc": float(auc),
            "accuracy": float(acc),
            "model_local_path": str(LOCAL_MODEL_PATH),
        }
        with open(ARTIFACT_DIR / "metrics.json", "w") as f:
            json.dump(info, f, indent=2)

        print(f"Training complete. AUC={auc:.3f}, ACC={acc:.3f}")
        print(f"Local model saved to: {LOCAL_MODEL_PATH}")
        print(f"MLflow run_id: {run.info.run_id}")

    return info

if __name__ == "__main__":
    main()

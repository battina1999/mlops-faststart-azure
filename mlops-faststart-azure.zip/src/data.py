from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path

RNG_SEED = 7

CONTRACTS = ["month-to-month", "one-year", "two-year"]

def generate_synthetic_churn(n: int = 5000, seed: int = RNG_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    age = rng.integers(18, 80, size=n)
    tenure = rng.integers(0, 72, size=n)
    monthly = rng.normal(80, 25, size=n).clip(10, 250)
    contract = rng.choice(CONTRACTS, size=n, p=[0.6, 0.25, 0.15])
    is_senior = age >= 60
    has_support = rng.random(n) < 0.55  # whether customer has premium support

    # logits for churn probability
    # higher churn for month-to-month, high charges, low tenure, seniors slightly higher
    logits = (
        -1.5
        + 0.8 * (contract == "month-to-month")
        + 0.2 * (contract == "one-year")
        + 0.015 * (monthly - 80)
        - 0.03 * tenure
        + 0.25 * is_senior
        - 0.35 * has_support
    )
    prob = 1 / (1 + np.exp(-logits))
    churn = (rng.random(n) < prob).astype(int)

    df = pd.DataFrame(
        {
            "age": age,
            "tenure_months": tenure,
            "monthly_charges": monthly.round(2),
            "contract_type": contract,
            "is_senior": is_senior,
            "has_support": has_support,
            "churn": churn,
        }
    )
    return df

def save_csv(df: pd.DataFrame, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)

from __future__ import annotations

import os
from prefect import flow, task, get_run_logger
from datetime import datetime
from pathlib import Path
from src.train import main as train_main

@task
def train_task():
    return train_main()

@task
def post_train(info: dict):
    logger = get_run_logger()
    logger.info(f"Training metrics: AUC={info.get('auc')}, ACC={info.get('accuracy')}")
    # placeholder: could register to registry/stage transition here

@flow(name="mlops-faststart-train")
def training_flow():
    info = train_task()
    post_train(info)

if __name__ == "__main__":
    training_flow()

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import os
import joblib
import mlflow
import numpy as np
from typing import List, Optional

APP_TITLE = "MLOps Faststart API"
DESCRIPTION = "FastAPI service for tabular churn-style model. Loads model from MODEL_URI (MLflow) or artifacts/model.joblib."
VERSION = "0.1.0"

app = FastAPI(title=APP_TITLE, description=DESCRIPTION, version=VERSION)

class InferenceRequest(BaseModel):
    age: int = Field(..., ge=0, le=120)
    tenure_months: int = Field(..., ge=0, le=600)
    monthly_charges: float = Field(..., ge=0)
    contract_type: str = Field(..., pattern="^(month-to-month|one-year|two-year)$")
    is_senior: bool
    has_support: bool

class InferenceResponse(BaseModel):
    churn_probability: float
    prediction: int
    model_source: str

_model = None
_model_source = None

def _load_model():
    global _model, _model_source
    if _model is not None:
        return _model
    model_uri = os.getenv("MODEL_URI")
    try:
        if model_uri:
            _model = mlflow.pyfunc.load_model(model_uri)
            _model_source = f"mlflow:{model_uri}"
        else:
            path = os.getenv("LOCAL_MODEL_PATH", "artifacts/model.joblib")
            _model = joblib.load(path)
            _model_source = f"local:{path}"
    except Exception as e:
        raise RuntimeError(f"Failed to load model: {e}")
    return _model

@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": _model is not None, "model_source": _model_source}

@app.post("/predict", response_model=InferenceResponse)
def predict(req: InferenceRequest):
    try:
        model = _load_model()
        # For sklearn Pipeline: accept dict -> 2D array/pandas DataFrame is handled internally by pyfunc or pipeline
        data = {
            "age": [req.age],
            "tenure_months": [req.tenure_months],
            "monthly_charges": [req.monthly_charges],
            "contract_type": [req.contract_type],
            "is_senior": [req.is_senior],
            "has_support": [req.has_support],
        }
        if hasattr(model, "predict_proba"):
            proba = float(model.predict_proba(data)[0][1])
            pred = int(proba >= 0.5)
        else:
            # mlflow.pyfunc returns numpy sometimes
            preds = model.predict(data)
            # support for models that return probability first
            if isinstance(preds, (list, np.ndarray)) and len(preds) > 0:
                p = float(preds[0])
            else:
                p = float(preds)
            proba = p if 0.0 <= p <= 1.0 else 1.0 / (1.0 + np.exp(-p))
            pred = int(proba >= 0.5)
        return InferenceResponse(churn_probability=proba, prediction=pred, model_source=_model_source or "unknown")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/batch_predict")
def batch_predict(requests: List[InferenceRequest]):
    model = _load_model()
    data = {
        "age": [r.age for r in requests],
        "tenure_months": [r.tenure_months for r in requests],
        "monthly_charges": [r.monthly_charges for r in requests],
        "contract_type": [r.contract_type for r in requests],
        "is_senior": [r.is_senior for r in requests],
        "has_support": [r.has_support for r in requests],
    }
    if hasattr(model, "predict_proba"):
        probas = model.predict_proba(data)[:, 1].tolist()
    else:
        preds = model.predict(data)
        probas = [float(p) for p in preds]
    return {"count": len(probas), "churn_probabilities": probas, "model_source": _model_source}

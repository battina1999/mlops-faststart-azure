from pathlib import Path
import json
from src.train import main

def test_training_produces_artifacts(tmp_path, monkeypatch):
    # Run training in temp dir to avoid polluting
    monkeypatch.chdir(tmp_path)
    info = main()
    assert "auc" in info and "accuracy" in info
    assert Path("artifacts/model.joblib").exists()
    assert Path("mlruns").exists()

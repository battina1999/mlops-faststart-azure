import json
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert "status" in r.json()

def test_predict_shape(monkeypatch, tmp_path):
    # Ensure local model exists by triggering train once if needed
    import os
    from src.train import main as train_main
    monkeypatch.chdir(tmp_path)
    train_main()

    # point API to local model
    os.environ["LOCAL_MODEL_PATH"] = "artifacts/model.joblib"

    from importlib import reload
    import app.main as app_mod
    reload(app_mod)
    local_client = TestClient(app_mod.app)

    payload = {
        "age": 40,
        "tenure_months": 12,
        "monthly_charges": 70.0,
        "contract_type": "month-to-month",
        "is_senior": False,
        "has_support": True
    }
    r = local_client.post("/predict", json=payload)
    assert r.status_code == 200
    body = r.json()
    assert 0.0 <= body["churn_probability"] <= 1.0
    assert body["prediction"] in [0, 1]

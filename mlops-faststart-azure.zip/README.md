# MLOps Faststart (Azure-first)

Production-ready skeleton for **MLOps / ML Platform Engineering** with:
- **Azure Container Apps / AKS (optional)** for serving
- **MLflow** tracking + model registry (local file URI by default)
- **Prefect** orchestration for training
- **FastAPI** inference service
- **CI/CD** via GitHub Actions, **Docker** container
- Reproducible **scikit-learn Pipeline** (including preprocessing) and synthetic dataset (no downloads)

> Built on 2025-08-11 — drop this into a GitHub repo and go.

## Architecture (overview)

```
                 +-------------------+
   client --->   |  FastAPI (uvicorn)|  ---> logs ---> Prom/Grafana (optional)
   batch ---->   |  /predict, /batch |  ---> drift ---> Evidently (optional)
                 +---------+---------+
                           |
                           | loads model from MODEL_URI (MLflow) or artifacts/model.joblib
                           v
                     +-----------+
                     |  Model    |
     Prefect Flow -> | Registry  | <- mlflow.sklearn.log_model
  (ingest->train->   +-----------+
   evaluate->register)      ^
                            |
                            v
                         DVC/data (optional), pandas, scikit-learn
```

## Quickstart

```bash
# 1) Create & activate venv (recommended)
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)

# 2) Install
make install

# 3) Train locally (logs to MLflow file store ./mlruns and saves artifacts/model.joblib)
make train

# 4) Run tests & lints
make test

# 5) Serve the API
make serve
# POST http://127.0.0.1:8000/predict  with a JSON body shown below

# 6) Build container
make docker-build
# 7) Run container
make docker-run
```

### Sample request to `/predict`
```json
{
  "age": 45,
  "tenure_months": 18,
  "monthly_charges": 89.5,
  "contract_type": "month-to-month",
  "is_senior": false,
  "has_support": true
}
```

## Environment Variables

- `MLFLOW_TRACKING_URI` — default `file:./mlruns`
- `MODEL_URI` — optional. If set to an MLflow model URI (e.g., `runs:/<run_id>/model`), the API loads that. Otherwise falls back to `artifacts/model.joblib`.

## Repo layout

```
.
├── app/                # FastAPI inference service
├── src/                # Training code (scikit-learn pipeline + MLflow)
├── pipelines/          # Prefect flow to orchestrate training
├── tests/              # pytest unit/integration tests
├── docker/             # Dockerfile for API
├── infra/bicep/        # Azure Container Apps skeleton (Bicep)
├── data/               # sample synthetic dataset (generated on first train)
├── artifacts/          # exported model for FastAPI fallback
├── .github/workflows/  # CI: lint + tests + docker build
└── Makefile
```

## Deploying to Azure (high level)

1. Build & push the container to **Azure Container Registry (ACR)**:
   - `az acr build -t <registry>.azurecr.io/mlops-faststart:latest .`
2. Deploy **Azure Container Apps** using the included Bicep file (edit parameters):
   - `az deployment group create -g <rg> -f infra/bicep/containerapp.bicep -p image=<acrImage> envName=<env>`

> The Bicep template is a starting point — adjust network, secrets, and scaling to your needs.

## Notes
- Uses a synthetic dataset so you can train without external downloads.
- End-to-end is **opinionated** but lightweight; swap Prefect⇄Airflow, Bicep⇄Terraform as desired.
- For a true registry workflow, stand up a remote MLflow server or use Databricks/AML registry and set `MODEL_URI`.

Happy shipping!
